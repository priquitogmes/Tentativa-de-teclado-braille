# Teclado Braille (esqueleto)

IME Android em Kotlin: 6 pontos, acordes multitoque, braille pt-BR grau 1.

## Rodar
1. Abra a pasta no Android Studio (ele gera o Gradle wrapper).
2. Rode no celular/emulador.
3. Configurações > Sistema > Teclado > Teclado na tela > ative "Teclado Braille".
4. Em qualquer campo de texto, troque para ele no seletor de teclados.

## Layout
Coluna esquerda: pontos 1, 2, 3 (cima p/ baixo). Coluna direita: 4, 5, 6.
Toque com vários dedos juntos e solte: o caractere é enviado.
Deslizar 1 dedo: → espaço, ← apagar, ↓ enter.
Ponto 6 sozinho = maiúscula; pontos 3456 = sinal de número.

## Próximos passos
- Modo tabletop (calibração dinâmica, como no TalkBack)
- Compatibilidade com TalkBack ligado (exploração por toque)
- liblouis para tabelas completas e grau 2
- Fala (TTS) a cada caractere
- Testes com usuários cegos

## Leitores de tela (Jieshuo, TalkBack)
- O Jieshuo não tem teclado braille nativo; ele depende de teclados de terceiros como este.
- Os 6 pontos são expostos como views virtuais (ExploreByTouchHelper): explorar com um
  dedo anuncia "Ponto N"; toque duplo envia só aquele ponto.
- NÃO TESTADO: acordes multitoque com a exploração por toque ligada. Testar em aparelho
  real com Jieshuo e com TalkBack: (1) explorar anuncia os pontos; (2) acorde de 2-3 dedos
  é entregue à view ou interpretado como gesto pelo leitor; (3) espaço/apagar/enter por
  deslize; (4) o leitor não repete cada letra duas vezes.

## Tabela liblouis (pendente)
Ainda usa BrailleTranslator.kt (tabela provisória escrita à mão). Para usar a
pt-pt-g1.utb da liblouis é preciso compilar a liblouis para Android (NDK/JNI) e
carregar a tabela dos assets; essa parte ainda não foi feita.
