package com.example.braillekeyboard

import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import java.util.Locale

class BrailleInputService : InputMethodService(), BrailleView.Listener {

    private val translator = BrailleTranslator()
    private val word = StringBuilder()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechEnabled = true

    override fun onCreate() {
        super.onCreate()
        speechEnabled = getSharedPreferences("braille", MODE_PRIVATE).getBoolean("speech", true)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                ttsReady = true
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    // ---- Fala ----

    private fun speak(text: String, force: Boolean = false) {
        if ((!speechEnabled && !force) || !ttsReady || text.isEmpty()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "braille")
    }

    /** Pontuação lida por extenso; o resto é lido como está. */
    private fun spoken(c: String): String = when (c) {
        "," -> "vírgula"
        "." -> "ponto"
        ";" -> "ponto e vírgula"
        ":" -> "dois pontos"
        "!" -> "exclamação"
        "?" -> "interrogação"
        "-" -> "hífen"
        else -> c
    }

    // ---- Teclado ----

    /** Tela cheia: sem o modo "extrair texto" do Android. */
    override fun onEvaluateFullscreenMode(): Boolean = false

    /** Não redimensiona nem desloca o app por baixo do teclado em tela cheia. */
    override fun onComputeInsets(outInsets: InputMethodService.Insets) {
        super.onComputeInsets(outInsets)
        val h = window.window?.decorView?.height ?: return
        outInsets.contentTopInsets = h
        outInsets.visibleTopInsets = h
    }

    override fun onCreateInputView(): View = BrailleView(this, this)

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        translator.reset()
        word.clear()
        speak("Teclado braille")
    }

    override fun onChord(mask: Int) {
        val text = translator.translate(mask)
        if (text.isNotEmpty()) {
            currentInputConnection?.commitText(text, 1)
            word.append(text)
            speak(spoken(text))
        } else {
            translator.indicator?.let { speak(it) }
        }
    }

    override fun onSpace() {
        translator.reset()
        val w = word.toString()
        word.clear()
        currentInputConnection?.commitText(" ", 1)
        speak(if (w.isNotEmpty()) w else "espaço")
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) {
            ic.commitText("", 1)
            word.clear()
            speak("apagou seleção")
            return
        }
        val prev = ic.getTextBeforeCursor(1, 0)?.toString().orEmpty()
        ic.deleteSurroundingText(1, 0)
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        speak(if (prev.isNotEmpty()) "apagou ${spoken(prev)}" else "nada para apagar")
    }

    override fun onEnter() {
        translator.reset()
        word.clear()
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        speak("enter")
    }

    override fun onToggleSpeech() {
        speechEnabled = !speechEnabled
        getSharedPreferences("braille", MODE_PRIVATE).edit().putBoolean("speech", speechEnabled).apply()
        speak(if (speechEnabled) "Fala ligada" else "Fala desligada", force = true)
    }
}
