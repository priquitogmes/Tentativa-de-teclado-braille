package com.example.braillekeyboard

/**
 * Traduz acordes de pontos braille (máscara de bits) em texto, braille pt-BR grau 1.
 * Ponto n = bit (n - 1). Ex.: pontos 1 e 4 = 0b001001.
 *
 * ATENÇÃO: confira as tabelas com a Grafia Braille para a Língua Portuguesa oficial.
 * Mais tarde, troque por liblouis (tabela pt-BR) para cobrir tudo.
 */
class BrailleTranslator {

    private var capitalNext = false
    private var numberMode = false

    /** Nome do último sinal consumido ("maiúscula", "número"), para a fala. */
    var indicator: String? = null
        private set

    private fun dots(s: String): Int = s.fold(0) { acc, c -> acc or (1 shl (c - '1')) }

    private val letters: Map<Int, Char> = mapOf(
        "1" to 'a', "12" to 'b', "14" to 'c', "145" to 'd', "15" to 'e',
        "124" to 'f', "1245" to 'g', "125" to 'h', "24" to 'i', "245" to 'j',
        "13" to 'k', "123" to 'l', "134" to 'm', "1345" to 'n', "135" to 'o',
        "1234" to 'p', "12345" to 'q', "1235" to 'r', "234" to 's', "2345" to 't',
        "136" to 'u', "1236" to 'v', "2456" to 'w', "1346" to 'x', "13456" to 'y',
        "1356" to 'z',
        // acentuadas
        "12346" to 'ç', "12356" to 'á', "123456" to 'é', "34" to 'í',
        "346" to 'ó', "23456" to 'ú', "16" to 'â', "126" to 'ê', "1456" to 'ô',
        "345" to 'ã', "246" to 'õ', "1256" to 'ü',
        // pontuação
        "2" to ',', "3" to '.', "23" to ';', "25" to ':', "235" to '!',
        "26" to '?', "36" to '-'
    ).mapKeys { dots(it.key) }

    // Depois do sinal de número, a–j viram 1–9, 0
    private val digits: Map<Int, Char> = mapOf(
        "1" to '1', "12" to '2', "14" to '3', "145" to '4', "15" to '5',
        "124" to '6', "1245" to '7', "125" to '8', "24" to '9', "245" to '0'
    ).mapKeys { dots(it.key) }

    private val numberSign = dots("3456")
    private val capitalSign = dots("6")

    fun translate(mask: Int): String {
        indicator = null
        when (mask) {
            numberSign -> { numberMode = true; indicator = "número"; return "" }
            capitalSign -> { capitalNext = true; indicator = "maiúscula"; return "" }
        }
        if (numberMode) {
            digits[mask]?.let { return it.toString() }
            numberMode = false
        }
        val c = letters[mask] ?: return ""
        val out = if (capitalNext) c.uppercaseChar() else c
        capitalNext = false
        return out.toString()
    }

    /** Chame em espaço/enter: encerra modo número e maiúscula pendente. */
    fun reset() {
        numberMode = false
        capitalNext = false
    }
}
