package com.example.braillekeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.customview.widget.ExploreByTouchHelper
import kotlin.math.abs

/**
 * Teclado de 6 pontos em duas colunas: esquerda = pontos 1,2,3 (cima p/ baixo),
 * direita = pontos 4,5,6. Os dedos que tocam formam um acorde; ao soltar todos,
 * o caractere é enviado.
 *
 * Na horizontal (celular deitado, 3 dedos de cada mão) os pontos viram 6 colunas na ordem
 * dos dedos: 3 2 1 | 4 5 6 (indicador de cada mão = pontos 1 e 4).
 *
 * Gestos de um dedo só: deslizar → direita = espaço, ← esquerda = apagar, ↓ = enter, ↑ = liga/desliga a fala.
 *
 * Acessibilidade: cada ponto é exposto como "view virtual" (ExploreByTouchHelper),
 * a API padrão do Android que leitores de tela (TalkBack, Jieshuo etc.) consomem.
 * Explorando com um dedo, o leitor anuncia "Ponto N"; toque duplo envia só aquele ponto.
 *
 * TODO: modo "tabletop" com calibração dinâmica (posições dos dedos definem os pontos).
 */
class BrailleView(context: Context, private val listener: Listener) : View(context) {

    interface Listener {
        fun onChord(mask: Int)
        fun onSpace()
        fun onBackspace()
        fun onEnter()
        fun onToggleSpeech()
    }

    private var pressedMask = 0
    private var chordMask = 0
    private var maxPointers = 0
    private var startX = 0f
    private var startY = 0f
    private var lastX = 0f
    private var lastY = 0f

    private val density = resources.displayMetrics.density
    private val swipeThreshold = 80 * density

    private val idlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY; style = Paint.Style.STROKE; strokeWidth = 4 * density
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.GRAY; textAlign = Paint.Align.CENTER; textSize = 28 * density
    }
    private val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1E88E5"); style = Paint.Style.FILL
    }

    private val a11y = object : ExploreByTouchHelper(this) {
        override fun getVirtualViewAt(x: Float, y: Float): Int = dotAt(x, y)

        override fun getVisibleVirtualViews(ids: MutableList<Int>) {
            for (dot in 1..6) ids.add(dot)
        }

        override fun onPopulateNodeForVirtualView(id: Int, node: AccessibilityNodeInfoCompat) {
            node.contentDescription = "Ponto $id"
            node.setBoundsInParent(boundsOfDot(id))
            node.addAction(AccessibilityNodeInfoCompat.ACTION_CLICK)
        }

        override fun onPerformActionForVirtualView(id: Int, action: Int, args: Bundle?): Boolean {
            if (action == AccessibilityNodeInfoCompat.ACTION_CLICK) {
                listener.onChord(1 shl (id - 1))
                return true
            }
            return false
        }
    }

    init {
        contentDescription = "Teclado braille de 6 pontos"
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        ViewCompat.setAccessibilityDelegate(this, a11y)
    }

    override fun dispatchHoverEvent(event: MotionEvent): Boolean =
        a11y.dispatchHoverEvent(event) || super.dispatchHoverEvent(event)

    /** Altura total da tela: o teclado ocupa a tela inteira enquanto aberto. */
    private fun screenHeight(): Int {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.height()
        else resources.displayMetrics.heightPixels
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), screenHeight())
    }

    /** Na horizontal: 6 colunas lado a lado, na ordem dos dedos (Perkins): 3 2 1 | 4 5 6. */
    private val landscapeOrder = intArrayOf(3, 2, 1, 4, 5, 6)

    private fun isLandscape() = width > height

    private fun dotAt(x: Float, y: Float): Int {
        if (isLandscape()) {
            val col = (x / (width / 6f)).toInt().coerceIn(0, 5)
            return landscapeOrder[col]
        }
        val col = if (x < width / 2f) 0 else 1
        val row = (y / (height / 3f)).toInt().coerceIn(0, 2)
        return col * 3 + row + 1 // 1..6
    }

    private fun boundsOfDot(dot: Int): Rect {
        if (isLandscape()) {
            val w = width / 6
            val left = landscapeOrder.indexOf(dot) * w
            return Rect(left, 0, left + w, height)
        }
        val col = (dot - 1) / 3
        val row = (dot - 1) % 3
        val left = col * width / 2
        val top = row * height / 3
        return Rect(left, top, left + width / 2, top + height / 3)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                chordMask = 0; pressedMask = 0; maxPointers = 1
                startX = e.x; startY = e.y
                press(e.x, e.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                maxPointers = maxOf(maxPointers, e.pointerCount)
                val i = e.actionIndex
                press(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                pressedMask = pressedMask and (1 shl (dotAt(e.getX(i), e.getY(i)) - 1)).inv()
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                lastX = e.x; lastY = e.y
                finishGesture()
            }
            MotionEvent.ACTION_CANCEL -> {
                chordMask = 0; pressedMask = 0; invalidate()
            }
        }
        return true
    }

    private fun press(x: Float, y: Float) {
        val bit = 1 shl (dotAt(x, y) - 1)
        chordMask = chordMask or bit
        pressedMask = pressedMask or bit
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        invalidate()
    }

    private fun finishGesture() {
        val dx = lastX - startX
        val dy = lastY - startY
        val isSwipe = maxPointers == 1 && (abs(dx) > swipeThreshold || abs(dy) > swipeThreshold)

        if (isSwipe) {
            when {
                abs(dx) >= abs(dy) && dx > 0 -> listener.onSpace()
                abs(dx) >= abs(dy) && dx < 0 -> listener.onBackspace()
                dy > 0 -> listener.onEnter()
                else -> listener.onToggleSpeech()
            }
        } else if (chordMask != 0) {
            listener.onChord(chordMask)
        }
        chordMask = 0; pressedMask = 0; maxPointers = 0
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val landscape = isLandscape()
        val r = if (landscape) minOf(width / 12f, height / 3f) * 0.8f
                else minOf(width / 6f, height / 6f) * 0.7f
        for (dot in 1..6) {
            val cx: Float
            val cy: Float
            if (landscape) {
                cx = width * (landscapeOrder.indexOf(dot) * 2 + 1) / 12f
                cy = height / 2f
            } else {
                val col = (dot - 1) / 3
                val row = (dot - 1) % 3
                cx = width * (if (col == 0) 0.25f else 0.75f)
                cy = height * (row * 2 + 1) / 6f
            }
            val on = pressedMask and (1 shl (dot - 1)) != 0
            canvas.drawCircle(cx, cy, r, if (on) activePaint else idlePaint)
            canvas.drawText(dot.toString(), cx, cy + textPaint.textSize / 3, textPaint)
        }
    }
}
