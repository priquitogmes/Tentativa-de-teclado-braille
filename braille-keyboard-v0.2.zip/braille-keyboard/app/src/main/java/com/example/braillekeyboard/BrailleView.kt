package com.example.braillekeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.customview.widget.ExploreByTouchHelper
import kotlin.math.abs

/**
 * Teclado de 6 pontos em duas colunas: esquerda = pontos 1,2,3 (cima p/ baixo),
 * direita = pontos 4,5,6. Os dedos que tocam formam um acorde; ao soltar todos,
 * o caractere é enviado.
 *
 * Gestos de um dedo só: deslizar → direita = espaço, ← esquerda = apagar, ↓ = enter.
 *
 * Acessibilidade: cada ponto é exposto como "view virtual" (ExploreByTouchHelper),
 * a API padrão do Android que leitores de tela (TalkBack, Jieshuo etc.) consomem.
 * Explorando com um dedo, o leitor anuncia "Ponto N"; toque duplo envia só aquele ponto.
 *
 * TODO: modo "tabletop" com calibração dinâmica (posições dos dedos definem os pontos).
 */
class BrailleView(context: Context, private val listener: Listener) : View(context) {

    interface Listener {
        fun onChord(mask: Int)
        fun onSpace()
        fun onBackspace()
        fun onEnter()
    }

    private var pressedMask = 0
    private var chordMask = 0
    private var maxPointers = 0
    private var startX = 0f
    private var startY = 0f
    private var lastX = 0f
    private var lastY = 0f

    private val density = resources.displayMetrics.density
    private val swipeThreshold = 80 * density

    private val idlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY; style = Paint.Style.STROKE; strokeWidth = 4 * density
    }
    private val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1E88E5"); style = Paint.Style.FILL
    }

    private val a11y = object : ExploreByTouchHelper(this) {
        override fun getVirtualViewAt(x: Float, y: Float): Int = dotAt(x, y)

        override fun getVisibleVirtualViews(ids: MutableList<Int>) {
            for (dot in 1..6) ids.add(dot)
        }

        override fun onPopulateNodeForVirtualView(id: Int, node: AccessibilityNodeInfoCompat) {
            node.contentDescription = "Ponto $id"
            node.setBoundsInParent(boundsOfDot(id))
            node.addAction(AccessibilityNodeInfoCompat.ACTION_CLICK)
        }

        override fun onPerformActionForVirtualView(id: Int, action: Int, args: Bundle?): Boolean {
            if (action == AccessibilityNodeInfoCompat.ACTION_CLICK) {
                listener.onChord(1 shl (id - 1))
                return true
            }
            return false
        }
    }

    init {
        contentDescription = "Teclado braille de 6 pontos"
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        ViewCompat.setAccessibilityDelegate(this, a11y)
    }

    override fun dispatchHoverEvent(event: MotionEvent): Boolean =
        a11y.dispatchHoverEvent(event) || super.dispatchHoverEvent(event)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = (280 * density).toInt()
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h)
    }

    private fun dotAt(x: Float, y: Float): Int {
        val col = if (x < width / 2f) 0 else 1
        val row = (y / (height / 3f)).toInt().coerceIn(0, 2)
        return col * 3 + row + 1 // 1..6
    }

    private fun boundsOfDot(dot: Int): Rect {
        val col = (dot - 1) / 3
        val row = (dot - 1) % 3
        val left = col * width / 2
        val top = row * height / 3
        return Rect(left, top, left + width / 2, top + height / 3)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                chordMask = 0; pressedMask = 0; maxPointers = 1
                startX = e.x; startY = e.y
                press(e.x, e.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                maxPointers = maxOf(maxPointers, e.pointerCount)
                val i = e.actionIndex
                press(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                pressedMask = pressedMask and (1 shl (dotAt(e.getX(i), e.getY(i)) - 1)).inv()
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                lastX = e.x; lastY = e.y
                finishGesture()
            }
            MotionEvent.ACTION_CANCEL -> {
                chordMask = 0; pressedMask = 0; invalidate()
            }
        }
        return true
    }

    private fun press(x: Float, y: Float) {
        val bit = 1 shl (dotAt(x, y) - 1)
        chordMask = chordMask or bit
        pressedMask = pressedMask or bit
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        invalidate()
    }

    private fun finishGesture() {
        val dx = lastX - startX
        val dy = lastY - startY
        val isSwipe = maxPointers == 1 && (abs(dx) > swipeThreshold || abs(dy) > swipeThreshold)

        if (isSwipe) {
            when {
                abs(dx) >= abs(dy) && dx > 0 -> listener.onSpace()
                abs(dx) >= abs(dy) && dx < 0 -> listener.onBackspace()
                dy > 0 -> listener.onEnter()
            }
        } else if (chordMask != 0) {
            listener.onChord(chordMask)
        }
        chordMask = 0; pressedMask = 0; maxPointers = 0
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val r = minOf(width / 6f, height / 6f) * 0.7f
        for (dot in 1..6) {
            val col = (dot - 1) / 3
            val row = (dot - 1) % 3
            val cx = width * (if (col == 0) 0.25f else 0.75f)
            val cy = height * (row * 2 + 1) / 6f
            val on = pressedMask and (1 shl (dot - 1)) != 0
            canvas.drawCircle(cx, cy, r, if (on) activePaint else idlePaint)
        }
    }
}
